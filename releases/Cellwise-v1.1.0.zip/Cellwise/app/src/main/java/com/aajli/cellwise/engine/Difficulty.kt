/*
 * Cellwise - offline Sudoku for travel.
 * Copyright (c) 2026 AAJLI Abdallah <ingenieur.aajli@gmail.com> - github.com/aajli-Abdallah - aajli.com
 * All rights reserved.
 */
package com.aajli.cellwise.engine

/** Target number of given digits per level. Technique-based rating arrives in v1.3.0. */
enum class Difficulty(val targetClues: Int) {
    EASY(40), MEDIUM(32), HARD(26)
}

/** A puzzle (0 = empty) and its unique solution, both 81 cells row by row. */
class Puzzle(val givens: IntArray, val solution: IntArray)
