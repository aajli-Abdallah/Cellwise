/*
 * Cellwise - offline Sudoku for travel.
 * Copyright (c) 2026 AAJLI Abdallah <ingenieur.aajli@gmail.com> - github.com/aajli-Abdallah - aajli.com
 * All rights reserved.
 */
package com.aajli.cellwise

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.aajli.cellwise.core.db.AppDatabase
import com.aajli.cellwise.core.settings.Settings
import com.aajli.cellwise.core.settings.SettingsStore
import com.aajli.cellwise.engine.Difficulty
import com.aajli.cellwise.engine.SudokuGenerator
import com.aajli.cellwise.feature.game.GameRules
import com.aajli.cellwise.feature.game.GameState
import com.aajli.cellwise.feature.game.data.GameEntity
import com.aajli.cellwise.feature.game.data.toEntity
import com.aajli.cellwise.feature.game.data.toState
import com.aajli.cellwise.feature.stats.Stats
import com.aajli.cellwise.feature.stats.StatsSummary
import com.aajli.cellwise.feature.stats.toRecord
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.channels.Channel
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.flowOn
import kotlinx.coroutines.flow.map
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.time.ZoneId
import java.util.UUID

enum class Screen { HOME, GAME, SETTINGS, ABOUT, STATS }

/** The single ViewModel. Feature logic lives in pure classes (GameRules, engine); this only wires state, timer and saving. */
class AppViewModel(app: Application) : AndroidViewModel(app) {

    private val dao = AppDatabase.get(app).gameDao()
    private val settingsStore = SettingsStore(app)
    val settings: StateFlow<Settings> = settingsStore.state

    /** Recomputed from the games table; only active while the Statistics screen is collecting it. */
    val stats: StateFlow<StatsSummary> = dao.observeAll()
        .map { rows -> Stats.compute(rows.mapNotNull { it.toRecord() }, System.currentTimeMillis(), ZoneId.systemDefault()) }
        .flowOn(Dispatchers.Default)
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), StatsSummary.EMPTY)

    private val _screen = MutableStateFlow(Screen.HOME)
    val screen: StateFlow<Screen> = _screen.asStateFlow()
    private val _game = MutableStateFlow<GameState?>(null)
    val game: StateFlow<GameState?> = _game.asStateFlow()
    private val _elapsed = MutableStateFlow(0L)
    val elapsed: StateFlow<Long> = _elapsed.asStateFlow()
    private val _generating = MutableStateFlow(false)
    val generating: StateFlow<Boolean> = _generating.asStateFlow()

    private val undoStack = ArrayDeque<Pair<List<Int>, List<Int>>>()
    private val saveQueue = Channel<GameEntity>(Channel.UNLIMITED) // ordered, single writer
    private var foreground = true

    init {
        viewModelScope.launch(Dispatchers.IO) { for (e in saveQueue) dao.upsert(e) }
        viewModelScope.launch {
            val e = withContext(Dispatchers.IO) { dao.getActive() }
            if (e != null) {
                val s = e.toState()
                if (s != null) { _game.value = s; _elapsed.value = e.elapsedSec }
                else saveQueue.trySend(e.copy(status = "ABANDONED")) // corrupt row
            }
        }
        viewModelScope.launch {
            var ticks = 0
            while (true) {
                delay(1000)
                val g = _game.value
                if (foreground && _screen.value == Screen.GAME && g != null && !g.won) {
                    _elapsed.value += 1
                    if (++ticks % 15 == 0) persist(g)
                }
            }
        }
    }

    private fun persist(s: GameState, status: String = if (s.won) "WON" else "IN_PROGRESS") {
        val now = System.currentTimeMillis()
        saveQueue.trySend(s.toEntity(_elapsed.value, status, now, if (status == "WON") now else null))
    }

    fun newGame(d: Difficulty) {
        if (_generating.value) return
        viewModelScope.launch {
            _generating.value = true
            try {
                val p = withContext(Dispatchers.Default) { SudokuGenerator.generate(d) }
                _game.value?.let { if (!it.won) persist(it, "ABANDONED") } // uses the old elapsed time
                val s = GameState(
                    id = UUID.randomUUID().toString(), difficulty = d,
                    givens = p.givens.toList(), solution = p.solution.toList(), values = p.givens.toList(),
                    notes = List(81) { 0 }, mistakes = 0, createdAt = System.currentTimeMillis()
                )
                undoStack.clear()
                _elapsed.value = 0
                _game.value = s
                persist(s)
                _screen.value = Screen.GAME
            } finally {
                _generating.value = false
            }
        }
    }

    fun continueGame() {
        val g = _game.value
        if (g != null && !g.won) _screen.value = Screen.GAME
    }

    /** Dismiss the "solved" dialog and go home. */
    fun leaveFinished() { _game.value = null; _screen.value = Screen.HOME }

    fun back() {
        if (_screen.value == Screen.GAME) _game.value?.let { if (!it.won) persist(it) }
        _screen.value = Screen.HOME
    }

    fun openSettings() { _screen.value = Screen.SETTINGS }
    fun openAbout() { _screen.value = Screen.ABOUT }
    fun openStats() { _screen.value = Screen.STATS }
    fun updateSettings(t: (Settings) -> Settings) = settingsStore.update(t)

    fun onForeground(f: Boolean) {
        foreground = f
        if (!f) _game.value?.let { if (!it.won) persist(it) }
    }

    private fun mutate(f: (GameState) -> GameState) {
        val g = _game.value ?: return
        val n = f(g)
        if (n == g) return
        if (n.values != g.values || n.notes != g.notes) {
            undoStack.addLast(g.values to g.notes)
            if (undoStack.size > 200) undoStack.removeFirstOrNull()
            _game.value = n
            persist(n)
        } else {
            _game.value = n // selection / notes-mode only: not saved
        }
    }

    fun select(i: Int) = mutate { GameRules.select(it, i) }
    fun digit(d: Int) = mutate { GameRules.enterDigit(it, d) }
    fun erase() = mutate { GameRules.erase(it) }
    fun toggleNotes() = mutate { GameRules.toggleNotes(it) }

    fun undo() {
        val g = _game.value ?: return
        if (g.won) return
        val u = undoStack.removeLastOrNull() ?: return
        val n = g.copy(values = u.first, notes = u.second)
        _game.value = n
        persist(n)
    }
}
