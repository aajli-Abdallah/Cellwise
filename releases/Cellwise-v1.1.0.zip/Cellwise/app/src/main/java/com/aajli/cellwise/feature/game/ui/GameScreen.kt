/*
 * Cellwise - offline Sudoku for travel.
 * Copyright (c) 2026 AAJLI Abdallah <ingenieur.aajli@gmail.com> - github.com/aajli-Abdallah - aajli.com
 * All rights reserved.
 */
package com.aajli.cellwise.feature.game.ui

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.FilledTonalButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.unit.dp
import com.aajli.cellwise.R
import com.aajli.cellwise.core.formatTime
import com.aajli.cellwise.core.settings.Settings
import com.aajli.cellwise.feature.game.GameState
import com.aajli.cellwise.ui.labelRes

@Composable
fun GameScreen(
    state: GameState, elapsed: Long, settings: Settings,
    onBack: () -> Unit, onSelect: (Int) -> Unit, onDigit: (Int) -> Unit,
    onErase: () -> Unit, onUndo: () -> Unit, onToggleNotes: () -> Unit,
    onNewSame: () -> Unit, onHome: () -> Unit
) {
    Column(Modifier.fillMaxSize().padding(horizontal = 12.dp)) {
        Row(Modifier.fillMaxWidth().padding(vertical = 4.dp), verticalAlignment = Alignment.CenterVertically) {
            TextButton(onClick = onBack) { Text("←") }
            Text(stringResource(state.difficulty.labelRes()), style = MaterialTheme.typography.titleMedium, modifier = Modifier.weight(1f))
            Text(stringResource(R.string.game_mistakes, state.mistakes), style = MaterialTheme.typography.bodyMedium)
            Text(formatTime(elapsed), style = MaterialTheme.typography.titleMedium, modifier = Modifier.padding(start = 16.dp, end = 8.dp))
        }
        SudokuGrid(state, settings, onSelect, Modifier.fillMaxWidth())
        Spacer(Modifier.weight(1f))
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            FilledTonalButton(onClick = onUndo, modifier = Modifier.weight(1f).height(52.dp)) { Text(stringResource(R.string.game_undo)) }
            FilledTonalButton(onClick = onErase, modifier = Modifier.weight(1f).height(52.dp)) { Text(stringResource(R.string.game_erase)) }
            if (state.notesMode) {
                Button(onClick = onToggleNotes, modifier = Modifier.weight(1f).height(52.dp)) { Text(stringResource(R.string.game_notes)) }
            } else {
                FilledTonalButton(onClick = onToggleNotes, modifier = Modifier.weight(1f).height(52.dp)) { Text(stringResource(R.string.game_notes)) }
            }
        }
        Spacer(Modifier.height(10.dp))
        DigitPad(state, onDigit)
        Spacer(Modifier.height(12.dp))
    }

    if (state.won) {
        AlertDialog(
            onDismissRequest = onHome,
            title = { Text(stringResource(R.string.win_title)) },
            text = { Text(stringResource(R.string.win_message, formatTime(elapsed), state.mistakes)) },
            confirmButton = { TextButton(onClick = onNewSame) { Text(stringResource(R.string.win_new)) } },
            dismissButton = { TextButton(onClick = onHome) { Text(stringResource(R.string.win_home)) } }
        )
    }
}

@Composable
private fun DigitPad(state: GameState, onDigit: (Int) -> Unit) {
    val cs = MaterialTheme.colorScheme
    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(4.dp)) {
        for (d in 1..9) {
            val left = 9 - state.placed(d)
            val enabled = left > 0 && !state.won
            Column(
                Modifier
                    .weight(1f)
                    .height(64.dp)
                    .clip(RoundedCornerShape(10.dp))
                    .background(cs.secondaryContainer.copy(alpha = if (enabled) 1f else 0.4f))
                    .clickable(enabled = enabled) { onDigit(d) },
                horizontalAlignment = Alignment.CenterHorizontally,
                verticalArrangement = Arrangement.Center
            ) {
                Text(d.toString(), style = MaterialTheme.typography.headlineSmall, color = cs.onSecondaryContainer)
                Text(left.toString(), style = MaterialTheme.typography.labelSmall, color = cs.onSecondaryContainer.copy(alpha = 0.7f))
            }
        }
    }
}
