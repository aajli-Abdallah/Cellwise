/*
 * Cellwise - offline Sudoku for travel.
 * Copyright (c) 2026 AAJLI Abdallah <ingenieur.aajli@gmail.com> - github.com/aajli-Abdallah - aajli.com
 * All rights reserved.
 */
package com.aajli.cellwise.feature.game.data

import androidx.room.Entity
import androidx.room.Index
import androidx.room.PrimaryKey

/**
 * One game, in progress or finished. Doubles as the history snapshot used by statistics (v1.1.0):
 * it keeps its own puzzle, solution, time and mistakes, never derived from current data.
 * status: IN_PROGRESS | WON | ABANDONED.
 */
@Entity(tableName = "games", indices = [Index("status")])
data class GameEntity(
    @PrimaryKey val id: String,
    val difficulty: String,
    val puzzle: String,
    val solution: String,
    val currentValues: String,
    val notes: String,
    val mistakes: Int,
    val elapsedSec: Long,
    val status: String,
    val createdAt: Long,
    val updatedAt: Long,
    val finishedAt: Long?
)
