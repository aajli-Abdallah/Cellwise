/*
 * Cellwise - offline Sudoku for travel.
 * Copyright (c) 2026 AAJLI Abdallah <ingenieur.aajli@gmail.com> - github.com/aajli-Abdallah - aajli.com
 * All rights reserved.
 */
package com.aajli.cellwise.core.db

import androidx.room.migration.Migration

/** Ordered list of Room migrations. Empty at schema version 1. */
object Migrations {
    val ALL: Array<Migration> = arrayOf()
}
