/*
 * Cellwise - offline Sudoku for travel.
 * Copyright (c) 2026 AAJLI Abdallah <ingenieur.aajli@gmail.com> - github.com/aajli-Abdallah - aajli.com
 * All rights reserved.
 */
package com.aajli.cellwise.feature.home

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.FilledTonalButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.unit.dp
import com.aajli.cellwise.R
import com.aajli.cellwise.core.CoreInfo
import com.aajli.cellwise.core.formatTime
import com.aajli.cellwise.engine.Difficulty
import com.aajli.cellwise.feature.game.GameState
import com.aajli.cellwise.ui.labelRes

@Composable
fun HomeScreen(
    active: GameState?, elapsed: Long, generating: Boolean,
    onContinue: () -> Unit, onNew: (Difficulty) -> Unit, onSettings: () -> Unit, onAbout: () -> Unit, onStats: () -> Unit
) {
    var pending by remember { mutableStateOf<Difficulty?>(null) }
    val cs = MaterialTheme.colorScheme

    Column(
        Modifier.fillMaxSize().padding(24.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.Center
    ) {
        Text(stringResource(R.string.app_name), style = MaterialTheme.typography.displayMedium, color = cs.primary)
        Text(stringResource(R.string.home_tagline), style = MaterialTheme.typography.bodyLarge, color = cs.onSurfaceVariant)
        Spacer(Modifier.height(32.dp))

        if (active != null) {
            Button(onClick = onContinue, enabled = !generating, modifier = Modifier.fillMaxWidth().height(56.dp)) {
                Text(stringResource(R.string.home_continue, stringResource(active.difficulty.labelRes()), formatTime(elapsed)))
            }
            Spacer(Modifier.height(16.dp))
        }
        Text(stringResource(R.string.home_new_game), style = MaterialTheme.typography.titleMedium)
        Spacer(Modifier.height(8.dp))
        Difficulty.values().forEach { d ->
            FilledTonalButton(
                onClick = { if (active != null) pending = d else onNew(d) },
                enabled = !generating,
                modifier = Modifier.fillMaxWidth().height(52.dp)
            ) { Text(stringResource(d.labelRes())) }
            Spacer(Modifier.height(8.dp))
        }
        if (generating) CircularProgressIndicator()
        Spacer(Modifier.height(16.dp))
        Row {
            TextButton(onClick = onStats) { Text(stringResource(R.string.home_stats)) }
            TextButton(onClick = onSettings) { Text(stringResource(R.string.home_settings)) }
            TextButton(onClick = onAbout) { Text(stringResource(R.string.home_about)) }
        }
        Spacer(Modifier.height(8.dp))
        Text(CoreInfo.COPYRIGHT, style = MaterialTheme.typography.labelSmall, color = cs.onSurfaceVariant)
    }

    pending?.let { d ->
        AlertDialog(
            onDismissRequest = { pending = null },
            title = { Text(stringResource(R.string.abandon_title)) },
            text = { Text(stringResource(R.string.abandon_message)) },
            confirmButton = { TextButton(onClick = { pending = null; onNew(d) }) { Text(stringResource(R.string.abandon_confirm)) } },
            dismissButton = { TextButton(onClick = { pending = null }) { Text(stringResource(R.string.cancel)) } }
        )
    }
}
