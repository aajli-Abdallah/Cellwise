/*
 * Cellwise - offline Sudoku for travel.
 * Copyright (c) 2026 AAJLI Abdallah <ingenieur.aajli@gmail.com> - github.com/aajli-Abdallah - aajli.com
 * All rights reserved.
 */
package com.aajli.cellwise.feature.game

import com.aajli.cellwise.engine.Difficulty

/** Immutable in-memory game. Lists have 81 entries, row by row; notes are bitmasks (bit d = digit d). */
data class GameState(
    val id: String,
    val difficulty: Difficulty,
    val givens: List<Int>,
    val solution: List<Int>,
    val values: List<Int>,
    val notes: List<Int>,
    val mistakes: Int,
    val createdAt: Long,
    val selected: Int = -1,
    val notesMode: Boolean = false,
    val won: Boolean = false
) {
    /** How many of digit [d] are correctly placed (0..9). */
    fun placed(d: Int): Int = (0 until 81).count { values[it] == d && solution[it] == d }
}

object GameRules {

    fun sharesUnit(a: Int, b: Int): Boolean =
        a / 9 == b / 9 || a % 9 == b % 9 || (a / 27 == b / 27 && (a % 9) / 3 == (b % 9) / 3)

    private fun List<Int>.withAt(i: Int, v: Int): List<Int> = toMutableList().also { it[i] = v }

    fun select(s: GameState, i: Int): GameState = s.copy(selected = i)

    fun toggleNotes(s: GameState): GameState = s.copy(notesMode = !s.notesMode)

    fun enterDigit(s: GameState, d: Int): GameState {
        val i = s.selected
        if (i < 0 || s.won || s.givens[i] != 0 || d !in 1..9) return s
        if (s.notesMode) {
            if (s.values[i] != 0) return s
            return s.copy(notes = s.notes.withAt(i, s.notes[i] xor (1 shl d)))
        }
        if (s.values[i] == d) return s
        val correct = d == s.solution[i]
        var notes = s.notes.withAt(i, 0)
        if (correct) {
            val mask = (1 shl d).inv()
            notes = notes.mapIndexed { idx, m -> if (idx != i && sharesUnit(idx, i)) m and mask else m }
        }
        val values = s.values.withAt(i, d)
        return s.copy(
            values = values, notes = notes,
            mistakes = s.mistakes + if (correct) 0 else 1,
            won = values == s.solution
        )
    }

    fun erase(s: GameState): GameState {
        val i = s.selected
        if (i < 0 || s.won || s.givens[i] != 0) return s
        if (s.values[i] == 0 && s.notes[i] == 0) return s
        return s.copy(values = s.values.withAt(i, 0), notes = s.notes.withAt(i, 0))
    }
}
