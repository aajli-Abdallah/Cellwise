/*
 * Cellwise - offline Sudoku for travel.
 * Copyright (c) 2026 AAJLI Abdallah <ingenieur.aajli@gmail.com> - github.com/aajli-Abdallah - aajli.com
 * All rights reserved.
 */
package com.aajli.cellwise

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.BackHandler
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.activity.viewModels
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.systemBarsPadding
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.getValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalView
import androidx.core.splashscreen.SplashScreen.Companion.installSplashScreen
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.aajli.cellwise.feature.about.AboutScreen
import com.aajli.cellwise.feature.game.ui.GameScreen
import com.aajli.cellwise.feature.home.HomeScreen
import com.aajli.cellwise.feature.settings.SettingsScreen
import com.aajli.cellwise.feature.stats.ui.StatsScreen
import com.aajli.cellwise.ui.theme.CellwiseTheme

class MainActivity : ComponentActivity() {
    private val vm: AppViewModel by viewModels()

    override fun onCreate(savedInstanceState: Bundle?) {
        installSplashScreen()
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContent {
            CellwiseTheme {
                Surface(Modifier.fillMaxSize(), color = MaterialTheme.colorScheme.background) {
                    Box(Modifier.fillMaxSize().systemBarsPadding()) { AppRoot(vm) }
                }
            }
        }
    }

    override fun onResume() { super.onResume(); vm.onForeground(true) }
    override fun onPause() { vm.onForeground(false); super.onPause() }
}

@Composable
fun AppRoot(vm: AppViewModel) {
    val screen by vm.screen.collectAsStateWithLifecycle()
    val game by vm.game.collectAsStateWithLifecycle()
    val elapsed by vm.elapsed.collectAsStateWithLifecycle()
    val settings by vm.settings.collectAsStateWithLifecycle()
    val generating by vm.generating.collectAsStateWithLifecycle()

    val view = LocalView.current
    DisposableEffect(screen, settings.keepScreenOn) {
        view.keepScreenOn = screen == Screen.GAME && settings.keepScreenOn
        onDispose { view.keepScreenOn = false }
    }
    BackHandler(enabled = screen != Screen.HOME) { vm.back() }

    when (screen) {
        Screen.HOME -> HomeScreen(
            active = game?.takeIf { !it.won }, elapsed = elapsed, generating = generating,
            onContinue = vm::continueGame, onNew = vm::newGame,
            onSettings = vm::openSettings, onAbout = vm::openAbout, onStats = vm::openStats
        )
        Screen.GAME -> game?.let { g ->
            GameScreen(
                state = g, elapsed = elapsed, settings = settings,
                onBack = vm::back, onSelect = vm::select, onDigit = vm::digit,
                onErase = vm::erase, onUndo = vm::undo, onToggleNotes = vm::toggleNotes,
                onNewSame = { vm.newGame(g.difficulty) }, onHome = vm::leaveFinished
            )
        }
        Screen.SETTINGS -> SettingsScreen(settings = settings, onChange = vm::updateSettings, onBack = vm::back)
        Screen.ABOUT -> AboutScreen(onBack = vm::back)
        Screen.STATS -> {
            val stats by vm.stats.collectAsStateWithLifecycle()
            StatsScreen(stats = stats, onBack = vm::back)
        }
    }
}
