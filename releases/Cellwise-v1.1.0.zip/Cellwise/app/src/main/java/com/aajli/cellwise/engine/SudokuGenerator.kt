/*
 * Cellwise - offline Sudoku for travel.
 * Copyright (c) 2026 AAJLI Abdallah <ingenieur.aajli@gmail.com> - github.com/aajli-Abdallah - aajli.com
 * All rights reserved.
 */
package com.aajli.cellwise.engine

import kotlin.random.Random

/** Generates puzzles with a guaranteed unique solution. Original algorithm, no external datasets. */
object SudokuGenerator {

    fun generate(difficulty: Difficulty, rnd: Random = Random.Default): Puzzle {
        val solution = SudokuSolver.randomSolution(rnd)
        val givens = solution.copyOf()
        var clues = 81
        val target = difficulty.targetClues

        // Pass 1: remove 180-degree symmetric pairs (classic newspaper look).
        for (i in (0..40).shuffled(rnd)) {
            if (clues <= target) break
            val j = 80 - i
            val a = givens[i]; val b = givens[j]
            givens[i] = 0; givens[j] = 0
            if (SudokuSolver.countSolutions(givens, 2) == 1) clues -= if (i == j) 1 else 2
            else { givens[i] = a; givens[j] = b }
        }
        // Pass 2: single removals if the target was not reached.
        if (clues > target) {
            for (i in (0 until 81).shuffled(rnd)) {
                if (clues <= target) break
                if (givens[i] == 0) continue
                val a = givens[i]
                givens[i] = 0
                if (SudokuSolver.countSolutions(givens, 2) == 1) clues-- else givens[i] = a
            }
        }
        return Puzzle(givens, solution)
    }
}
