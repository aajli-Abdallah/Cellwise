# Cellwise v1.1.0

Offline number-puzzle game (9x9 logic grid) for flights and trips. No account, no ads, no network.
Package `com.aajli.cellwise` · Kotlin · Jetpack Compose (Material 3) · Room (KSP) · minSdk 26 · targetSdk 35.

Copyright (c) 2026 AAJLI Abdallah - ingenieur.aajli@gmail.com - github.com/aajli-Abdallah - aajli.com. All rights reserved.

## Features (v1.1.0)
- On-device generator and solver; every puzzle has exactly one solution. Levels: Easy, Medium, Hard.
- Canvas grid, large digit pad with remaining counts, pencil notes, undo, erase.
- Mistake counter and optional red highlight, same-number highlight, live timer.
- Automatic save of the game in progress (Room); resume after closing the app.
- Keep-screen-awake while playing, portrait only, dynamic Material 3 colors (Android 12+), themed adaptive icon, splash.
- Statistics screen: won / win rate / streaks, per-level table (won, best, average, mistakes), wins-per-day chart, recent games.
- About screen with version (BuildConfig), copyright and open-source notices.

## Build
Open the folder in Android Studio (it reads `gradle/wrapper/gradle-wrapper.properties`, Gradle 8.9, AGP 8.5.2, Kotlin 2.0.20).
Command line needs `gradlew`, `gradlew.bat` and `gradle/wrapper/gradle-wrapper.jar` copied from another project.
Unit tests: `./gradlew testDebugUnitTest` (engine, rules, time format).

## Versioning
`versionName` = `M.m.p` (corrections append two digits: 1.4.0 -> 1.4.01). `versionCode` = M*10000 + m*100 + p.
On every version update together: `app/build.gradle.kts` (versionName, versionCode), this title, `CHANGELOG.md`, the zip name, the project doc.

## Docs
- `docs/ARCHITECTURE.md` - modules, rules, data model, extension points.
- `docs/ROADMAP.md` - planned versions and decisions.
- `CHANGELOG.md` - history, newest first.
