/*
 * Cellwise - offline Sudoku for travel.
 * Copyright (c) 2026 AAJLI Abdallah <ingenieur.aajli@gmail.com> - github.com/aajli-Abdallah - aajli.com
 * All rights reserved.
 */
package com.aajli.cellwise.core.settings

import com.aajli.cellwise.core.backup.BackupSection
import com.aajli.cellwise.core.backup.ImportMode
import com.aajli.cellwise.core.backup.SectionPlan

/** Settings are applied only in Replace mode; Merge leaves this phone's settings untouched. */
class SettingsBackupSection(private val store: SettingsStore) : BackupSection {
    override val key = "settings"

    override suspend fun export(): Map<String, Any?> {
        val s = store.state.value
        return mapOf(
            "schema" to 1,
            "values" to mapOf(
                "highlightMistakes" to s.highlightMistakes,
                "keepScreenOn" to s.keepScreenOn,
                "highlightSameNumber" to s.highlightSameNumber,
                "dynamicColors" to s.dynamicColors
            )
        )
    }

    private fun parse(body: Map<String, Any?>): Settings? {
        val v = body["values"] as? Map<*, *> ?: return null
        val cur = store.state.value
        return Settings(
            highlightMistakes = v["highlightMistakes"] as? Boolean ?: cur.highlightMistakes,
            keepScreenOn = v["keepScreenOn"] as? Boolean ?: cur.keepScreenOn,
            highlightSameNumber = v["highlightSameNumber"] as? Boolean ?: cur.highlightSameNumber,
            dynamicColors = v["dynamicColors"] as? Boolean ?: cur.dynamicColors
        )
    }

    override suspend fun plan(body: Map<String, Any?>, mode: ImportMode): SectionPlan {
        if (mode == ImportMode.MERGE) return SectionPlan(key, 0, 0, 0, replaceOnly = true)
        val p = parse(body) ?: return SectionPlan(key, 0, 0, 0, invalid = 1)
        return if (p == store.state.value) SectionPlan(key, 0, 0, 1) else SectionPlan(key, 0, 1, 0)
    }

    override suspend fun apply(body: Map<String, Any?>, mode: ImportMode) {
        if (mode != ImportMode.REPLACE) return
        parse(body)?.let { p -> store.update { p } }
    }
}
