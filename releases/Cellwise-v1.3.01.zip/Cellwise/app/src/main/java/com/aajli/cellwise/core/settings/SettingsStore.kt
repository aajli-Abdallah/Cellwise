/*
 * Cellwise - offline Sudoku for travel.
 * Copyright (c) 2026 AAJLI Abdallah <ingenieur.aajli@gmail.com> - github.com/aajli-Abdallah - aajli.com
 * All rights reserved.
 */
package com.aajli.cellwise.core.settings

import android.content.Context
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow

data class Settings(
    val highlightMistakes: Boolean = true,
    val keepScreenOn: Boolean = true,
    val highlightSameNumber: Boolean = true,
    val dynamicColors: Boolean = false   // false = Cellwise palette, true = wallpaper colors (Android 12+)
)

/** SharedPreferences-backed settings exposed as a StateFlow. Backup section arrives in v1.2.0. */
class SettingsStore(context: Context) {
    private val prefs = context.getSharedPreferences("cellwise_settings", Context.MODE_PRIVATE)
    private val _state = MutableStateFlow(read())
    val state: StateFlow<Settings> = _state.asStateFlow()

    private fun read() = Settings(
        highlightMistakes = prefs.getBoolean(K_MISTAKES, true),
        keepScreenOn = prefs.getBoolean(K_AWAKE, true),
        highlightSameNumber = prefs.getBoolean(K_SAME, true),
        dynamicColors = prefs.getBoolean(K_DYNAMIC, false)
    )

    fun update(transform: (Settings) -> Settings) {
        val n = transform(_state.value)
        prefs.edit()
            .putBoolean(K_MISTAKES, n.highlightMistakes)
            .putBoolean(K_AWAKE, n.keepScreenOn)
            .putBoolean(K_SAME, n.highlightSameNumber)
            .putBoolean(K_DYNAMIC, n.dynamicColors)
            .apply()
        _state.value = n
    }

    private companion object {
        const val K_MISTAKES = "highlight_mistakes"
        const val K_AWAKE = "keep_screen_on"
        const val K_SAME = "highlight_same"
        const val K_DYNAMIC = "dynamic_colors"
    }
}
