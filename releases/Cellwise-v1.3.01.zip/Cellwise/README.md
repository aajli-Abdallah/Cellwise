# Cellwise v1.3.01

Offline number-puzzle game (9x9 logic grid) for flights and trips. No account, no ads, no network.
Package `com.aajli.cellwise` · Kotlin · Jetpack Compose (Material 3) · Room (KSP) · minSdk 26 · targetSdk 35.

Copyright (c) 2026 AAJLI Abdallah - ingenieur.aajli@gmail.com - github.com/aajli-Abdallah - aajli.com. All rights reserved.

## Features (v1.3.01)
- On-device generator and solver; every puzzle has exactly one solution. Levels: Easy, Medium, Hard.
- Canvas grid, large digit pad with remaining counts, pencil notes, undo, erase.
- Mistake counter and optional red highlight, same-number highlight, live timer.
- Automatic save of the game in progress (Room); resume after closing the app.
- Keep-screen-awake while playing, portrait only, dynamic Material 3 colors (Android 12+), themed adaptive icon, splash.
- Statistics screen: won / win rate / streaks, per-level table (won, best, average, mistakes), wins-per-day chart, recent games.
- Own visual identity: indigo + amber palette, serif "printed puzzle" digits, living logo, new adaptive/themed icon and splash (wallpaper colors optional).
- Difficulty from a technique rating (singles = Easy; locked candidates / naked pairs = Medium; hidden pairs, X-Wing or beyond = Hard).
- Hint (names the technique, highlights where to look, Reveal places the digit), Check (marks wrong digits on demand), Auto notes.
- Import a grid from paper: tap-and-type or paste text, duplicate highlight, solver check (no solution / several solutions / unique), then play it.
- Backup: share a JSON backup file, import from file / WhatsApp / Files, preview (new, updated, unchanged), Merge or Replace, automatic daily local backup (last 7), weekly share reminder.
- About screen with version (BuildConfig), copyright and open-source notices.

## Build
Open the folder in Android Studio (it reads `gradle/wrapper/gradle-wrapper.properties`, Gradle 8.9, AGP 8.5.2, Kotlin 2.0.20).
Command line needs `gradlew`, `gradlew.bat` and `gradle/wrapper/gradle-wrapper.jar` copied from another project.
Unit tests: `./gradlew testDebugUnitTest` (engine, rules, time format).

## Versioning
`versionName` = `M.m.p` (corrections append two digits: 1.4.0 -> 1.4.01). `versionCode` = M*10000 + m*100 + p.
On every version update together: `app/build.gradle.kts` (versionName, versionCode), this title, `CHANGELOG.md`, the zip name, the project doc.

## Docs
- `docs/ARCHITECTURE.md` - modules, rules, data model, extension points.
- `docs/DESIGN.md` - palette, typography, components, icon construction.
- `docs/TECHNIQUES.md` - techniques, rating, hint algorithm, grid import.
- `docs/BACKUP_FORMAT.md` - file format, versions, merge rules.
- `docs/SIGNING.md` - release keystore.
- `docs/STATS.md` - statistics definitions.
- `docs/ROADMAP.md` - planned versions and decisions.
- `CHANGELOG.md` - history, newest first.
