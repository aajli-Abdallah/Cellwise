/*
 * Cellwise - offline Sudoku for travel.
 * Copyright (c) 2026 AAJLI Abdallah <ingenieur.aajli@gmail.com> - github.com/aajli-Abdallah - aajli.com
 * All rights reserved.
 */
package com.aajli.cellwise.feature.settings

import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.unit.dp
import com.aajli.cellwise.R
import com.aajli.cellwise.core.settings.Settings
import com.aajli.cellwise.ui.ScreenHeader

@Composable
fun SettingsScreen(settings: Settings, onChange: ((Settings) -> Settings) -> Unit, onBack: () -> Unit) {
    Column(Modifier.fillMaxWidth()) {
        ScreenHeader(stringResource(R.string.settings_title), onBack)
        SwitchRow(stringResource(R.string.setting_mistakes), stringResource(R.string.setting_mistakes_desc), settings.highlightMistakes) { v ->
            onChange { it.copy(highlightMistakes = v) }
        }
        SwitchRow(stringResource(R.string.setting_same), null, settings.highlightSameNumber) { v ->
            onChange { it.copy(highlightSameNumber = v) }
        }
        SwitchRow(stringResource(R.string.setting_awake), null, settings.keepScreenOn) { v ->
            onChange { it.copy(keepScreenOn = v) }
        }
    }
}

@Composable
private fun SwitchRow(title: String, desc: String?, checked: Boolean, onToggle: (Boolean) -> Unit) {
    Row(Modifier.fillMaxWidth().padding(horizontal = 20.dp, vertical = 12.dp), verticalAlignment = Alignment.CenterVertically) {
        Column(Modifier.weight(1f)) {
            Text(title, style = MaterialTheme.typography.bodyLarge)
            if (desc != null) Text(desc, style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
        }
        Switch(checked = checked, onCheckedChange = onToggle)
    }
}
