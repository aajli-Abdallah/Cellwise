/*
 * Cellwise - offline Sudoku for travel.
 * Copyright (c) 2026 AAJLI Abdallah <ingenieur.aajli@gmail.com> - github.com/aajli-Abdallah - aajli.com
 * All rights reserved.
 */
package com.aajli.cellwise.ui.theme

import android.os.Build
import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.dynamicDarkColorScheme
import androidx.compose.material3.dynamicLightColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext

private val Light = lightColorScheme(
    primary = Color(0xFF3949AB), onPrimary = Color.White,
    primaryContainer = Color(0xFFDDE1FF), onPrimaryContainer = Color(0xFF00105C),
    secondaryContainer = Color(0xFFE1E3F4), onSecondaryContainer = Color(0xFF1A1D2C),
    tertiaryContainer = Color(0xFFFFD9E2), surfaceVariant = Color(0xFFE3E1EC)
)
private val Dark = darkColorScheme(
    primary = Color(0xFFB9C3FF), onPrimary = Color(0xFF08218A),
    primaryContainer = Color(0xFF2B3C93), onPrimaryContainer = Color(0xFFDDE1FF),
    secondaryContainer = Color(0xFF3F4156), onSecondaryContainer = Color(0xFFDDE1F4),
    tertiaryContainer = Color(0xFF5C3A49), surfaceVariant = Color(0xFF46464F)
)

/** Dynamic (wallpaper) colors on Android 12+, fixed indigo palette below. Follows the system dark mode. */
@Composable
fun CellwiseTheme(content: @Composable () -> Unit) {
    val dark = isSystemInDarkTheme()
    val ctx = LocalContext.current
    val scheme = when {
        Build.VERSION.SDK_INT >= Build.VERSION_CODES.S ->
            if (dark) dynamicDarkColorScheme(ctx) else dynamicLightColorScheme(ctx)
        dark -> Dark
        else -> Light
    }
    MaterialTheme(colorScheme = scheme, content = content)
}
