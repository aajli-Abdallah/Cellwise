/*
 * Cellwise - offline Sudoku for travel.
 * Copyright (c) 2026 AAJLI Abdallah <ingenieur.aajli@gmail.com> - github.com/aajli-Abdallah - aajli.com
 * All rights reserved.
 */
package com.aajli.cellwise.feature.game.ui

import android.graphics.Paint as NativePaint
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.layout.aspectRatio
import androidx.compose.material3.MaterialTheme
import androidx.compose.runtime.Composable
import androidx.compose.runtime.rememberUpdatedState
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.drawscope.drawIntoCanvas
import androidx.compose.ui.graphics.nativeCanvas
import androidx.compose.ui.graphics.toArgb
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.unit.dp
import com.aajli.cellwise.core.settings.Settings
import com.aajli.cellwise.feature.game.GameRules
import com.aajli.cellwise.feature.game.GameState

/** Canvas-drawn 9x9 grid. Pure rendering: all game logic stays in GameRules. */
@Composable
fun SudokuGrid(
    state: GameState, settings: Settings, onSelect: (Int) -> Unit, modifier: Modifier = Modifier,
    errorCells: Set<Int>? = null,      // when set, exactly these cells are drawn as errors (import screen)
    hintCells: Set<Int> = emptySet(),  // the unit a hint points at
    hintTarget: Int = -1               // the cell a hint points at
) {
    val cs = MaterialTheme.colorScheme
    val select = rememberUpdatedState(onSelect)
    val cGiven = cs.onSurface.toArgb()
    val cUser = cs.primary.toArgb()
    val cError = cs.error.toArgb()
    val cNote = cs.onSurfaceVariant.toArgb()
    val bgSelected = cs.primaryContainer
    val bgPeer = cs.surfaceVariant.copy(alpha = 0.55f)
    val bgSame = cs.tertiaryContainer
    val lineThin = cs.outlineVariant
    val lineThick = cs.onSurface
    val bgHint = cs.primaryContainer.copy(alpha = 0.5f)
    val bgHintTarget = cs.tertiary.copy(alpha = 0.45f)

    Canvas(
        modifier
            .aspectRatio(1f)
            .pointerInput(Unit) {
                detectTapGestures { o ->
                    val cell = size.width / 9f
                    val c = (o.x / cell).toInt().coerceIn(0, 8)
                    val r = (o.y / cell).toInt().coerceIn(0, 8)
                    select.value(r * 9 + c)
                }
            }
    ) {
        val cell = size.width / 9f
        val sel = state.selected
        val selVal = if (sel >= 0) state.values[sel] else 0

        for (i in 0 until 81) {
            val bg = when {
                i == hintTarget -> bgHintTarget
                i == sel -> bgSelected
                i in hintCells -> bgHint
                settings.highlightSameNumber && selVal != 0 && state.values[i] == selVal -> bgSame
                sel >= 0 && GameRules.sharesUnit(i, sel) -> bgPeer
                else -> null
            }
            if (bg != null) drawRect(bg, Offset((i % 9) * cell, (i / 9) * cell), Size(cell, cell))
        }

        for (k in 0..9) {
            val thick = k % 3 == 0
            val w = if (thick) 2.5.dp.toPx() else 0.8.dp.toPx()
            val col = if (thick) lineThick else lineThin
            drawLine(col, Offset(k * cell, 0f), Offset(k * cell, size.height), w)
            drawLine(col, Offset(0f, k * cell), Offset(size.width, k * cell), w)
        }

        drawIntoCanvas { canvas ->
            val nc = canvas.nativeCanvas
            val p = NativePaint(NativePaint.ANTI_ALIAS_FLAG).apply { textAlign = NativePaint.Align.CENTER }
            for (i in 0 until 81) {
                val r = i / 9; val c = i % 9
                val v = state.values[i]
                if (v != 0) {
                    val given = state.givens[i] != 0
                    val wrong = if (errorCells != null) i in errorCells
                    else !given && (settings.highlightMistakes || state.showErrors) && v != state.solution[i]
                    p.color = if (wrong) cError else if (given) cGiven else cUser
                    p.textSize = cell * 0.6f
                    p.isFakeBoldText = given
                    val fm = p.fontMetrics
                    nc.drawText(v.toString(), c * cell + cell / 2, r * cell + cell / 2 - (fm.ascent + fm.descent) / 2, p)
                } else if (state.notes[i] != 0) {
                    p.color = cNote
                    p.textSize = cell * 0.25f
                    p.isFakeBoldText = false
                    val fm = p.fontMetrics
                    val sub = cell / 3
                    for (d in 1..9) if (state.notes[i] and (1 shl d) != 0) {
                        val cx = c * cell + sub * ((d - 1) % 3) + sub / 2
                        val cy = r * cell + sub * ((d - 1) / 3) + sub / 2 - (fm.ascent + fm.descent) / 2
                        nc.drawText(d.toString(), cx, cy, p)
                    }
                }
            }
        }
    }
}
