# Architecture (v1.0.0)

## Principles
Offline first, no account. One Gradle module, package-by-feature. Pure logic is separated from Android so it is unit-testable.
A feature may depend on `core` and `engine`; features never import each other (the root `AppViewModel`/`AppRoot` wires them).

## Packages (`com.aajli.cellwise`)
| Package | Role | Android deps |
|---|---|---|
| `engine` | `SudokuSolver`, `SudokuGenerator`, `Difficulty`, `Puzzle` | none |
| `core` | `CoreInfo` (owner/copyright), `Format`, `settings/SettingsStore`, `db/AppDatabase`, `db/Migrations` | yes |
| `feature/game` | `GameState` + `GameRules` (pure), `data/` (entity, DAO, mapper), `ui/` (grid, screen) | ui, data |
| `feature/home`, `feature/settings`, `feature/about` | screens | ui |
| `ui` | theme, shared components, labels | ui |
| root | `MainActivity`, `AppViewModel`, `AppRoot` | yes |

## Engine
Grid = `IntArray(81)`, 0 = empty. Solver: row/col/box bitmasks, picks the empty cell with fewest candidates, stops after `limit` solutions.
`countSolutions(grid, 2) == 1` is the uniqueness test. Generator: random full solution, remove 180-degree symmetric pairs while unique, then single cells if the clue target is missed. Difficulty = clue target (40 / 32 / 26); technique-based rating is planned for v1.3.0.

## Game state
`GameState` is immutable (81-element lists; notes = bitmask per cell). `GameRules` returns new states. Win = `values == solution`.
Placing a correct digit clears that digit from peer notes. A wrong digit increments `mistakes` (always counted; display is a setting).
Undo stack (values + notes, max 200) lives in the ViewModel and is not persisted. Selection and notes mode are not persisted.

## Persistence
Room `games` table, one row per game, also the statistics source (v1.1.0): `id` (UUID), `difficulty`, `puzzle`, `solution`, `currentValues` (81 chars), `notes` (81 comma-separated bitmasks), `mistakes`, `elapsedSec`, `status` (IN_PROGRESS | WON | ABANDONED), `createdAt`, `updatedAt`, `finishedAt`.
All writes go through one ordered channel consumed by a single IO coroutine (no reordered saves). Saves happen after each change, every 15 s, on pause and on leaving the game. Starting a new game marks the old one ABANDONED.
Rules: schema change = bump version + migration in `Migrations.ALL`, never destructive; `exportSchema` is on (`app/schemas/`, commit it).

## Timer
Ticks once per second in the ViewModel only while the app is in foreground, the game screen is open and the game is not won. `elapsed` is a separate StateFlow to avoid recomposing the grid every second.

## UI
Compose Material 3, dynamic colors on Android 12+, indigo fallback. Edge-to-edge with system bar padding. The grid is a Canvas (native text for digits and notes) so there are no extra dependencies. Portrait only in 1.0.0.

## Extension points
- New screen/feature: add `feature/<name>/`, a `Screen` enum value, a branch in `AppRoot`.
- New table: entity + DAO in the feature, register in `AppDatabase`, add a migration.
- Backup (v1.2.0): each feature registers a `BackupSection` (key, export, import, merge rule, upgrade step); backup code never changes when a feature is added.
- New game types (v2.0.0): `GameModule` interface; the engine package stays Android-free.
