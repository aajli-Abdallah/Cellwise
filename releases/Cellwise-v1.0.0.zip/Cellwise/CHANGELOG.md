# Changelog (newest first)

## 1.0.0 - 2026-11-05
First playable version.
- Project skeleton: package-by-feature, one ViewModel, Room v1 (`games` table, schema export on), empty migrations hook.
- Pure Kotlin engine: bitmask solver (MRV), generator with unique-solution check, 3 levels.
- Game: Canvas grid, digit pad with remaining counts, notes, undo (200 steps, in memory), erase, mistakes, timer, win dialog.
- Autosave of the game in progress; abandoned games are recorded as ABANDONED (used by stats in 1.1.0).
- Settings: highlight mistakes, highlight same number, keep screen on.
- Themed adaptive icon (monochrome layer), splash, dynamic colors, edge-to-edge.
- About screen: version from BuildConfig, copyright, licenses.
- Unit tests: solver, generator, rules, time format.
