# Techniques, rating, hints and grid import (v1.3.0)

All in pure Kotlin (`engine/`), covered by unit tests that also check every step against the real solution.

## Techniques (rank)
| Rank | Technique | Rule |
|---|---|---|
| 1 | Naked single | a cell has one candidate left |
| 2 | Hidden single | a digit has one possible cell in a row, column or box |
| 3 | Pointing pair | a digit's candidates in a box lie on one line: remove it from the rest of the line |
| 4 | Box/line reduction | a digit's candidates in a row/column lie in one box: remove it from the rest of the box |
| 5 | Naked pair | two cells of a unit share the same two candidates: remove them from the other cells |
| 6 | Hidden pair | two digits fit only the same two cells of a unit: remove the other candidates from those cells |
| 7 | X-Wing | a digit in two rows (or columns) only in the same two columns (rows): remove it elsewhere in those columns (rows) |
| 9 | Guess | the techniques above are not enough |

`TechniqueSolver` keeps a candidate mask per cell and always applies the simplest technique available (`nextStep()`).

## Rating and levels
`SudokuRater.rate(givens)` solves with the techniques and returns the hardest one used. Level: rank 1-2 = Easy, 3-5 = Medium, 6+ (including Guess) = Hard. A grid is "unsolved" when the techniques stall; it is rated Guess/Hard.
The generator removes clues (symmetric pairs first, then single clues, always keeping a unique solution), rates the result, keeps removing if it is too easy, and starts over if it is too hard, up to 40 attempts. The displayed level is always the real rating of the puzzle.
Measured on the JVM: about 1-20 ms per puzzle (max about 110 ms); expect a few times more on a phone.

## Hints
`HintEngine.next(values, solution)` runs the solver on the current board (givens + the player's digits, notes ignored) until a placement appears. The hint names the technique, the unit to look at and the cell; if eliminations were needed first, the last one is mentioned. If no technique applies, the digit comes from the solution (shown as "Advanced logic"). A grid containing wrong digits shows them in red instead of a hint. Each new hint increments `hints`; Reveal places the digit without a second count.

## Check and auto notes
Check marks wrong digits (compared with the solution) until the board changes; the "highlight mistakes" setting keeps them always on. Auto notes fills every empty cell with the digits not used in its row, column and box (replaces existing notes; undoable).

## Importing a printed grid
- Tap a cell, then a digit: the cursor moves to the next cell. Or Paste text: 81 cells row by row; digits 1-9 are clues, `0 . - _ x *` are empty, spaces and `|` are ignored, lines containing `+` or box-drawing characters are skipped (ASCII borders). A line of only dashes without `+` would be read as empty cells.
- Live: repeated digits in a row, column or box are red.
- Start: fewer than 17 clues is refused; 0 solutions = a clue is mistyped; several solutions = a clue is missing or misread; exactly one = rated and played (`imported = 1`). Not included: showing the full solution, camera scan.
